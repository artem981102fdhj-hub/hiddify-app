import 'package:flutter/material.dart';
import 'package:hiddify/core/localization/translations.dart';
import 'package:hiddify/features/connection/notifier/connection_notifier.dart';
import 'package:hiddify/features/profile/notifier/active_profile_notifier.dart';
import 'package:hiddify/features/profile/widget/profile_tile.dart';
import 'package:hiddify/features/proxy/overview/proxies_overview_notifier.dart';
import 'package:hiddify/features/proxy/widget/proxy_tile.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

/// The lower part of the home screen: the active subscription card with the list of its servers
/// right under it. The core only knows the servers while the VPN runs, so before connecting the
/// list shows a hint instead.
class HomeServersPanel extends ConsumerWidget {
  const HomeServersPanel({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final t = ref.watch(translationsProvider).requireValue;
    final activeProfile = ref.watch(activeProfileProvider);
    final proxies = ref.watch(proxiesOverviewNotifierProvider);
    final running = ref.watch(serviceRunningProvider);

    final Widget profileSliver = switch (activeProfile) {
      AsyncData(value: final profile?) => SliverToBoxAdapter(
        child: ProfileTile(profile: profile, isMain: true, margin: const EdgeInsets.fromLTRB(12, 12, 12, 4)),
      ),
      _ => const SliverToBoxAdapter(child: SizedBox.shrink()),
    };

    final Widget testSliver = SliverToBoxAdapter(
      child: running
          ? Align(
              alignment: AlignmentDirectional.centerEnd,
              child: Padding(
                padding: const EdgeInsetsDirectional.only(end: 12),
                child: TextButton.icon(
                  onPressed: () async => await ref.read(proxiesOverviewNotifierProvider.notifier).urlTest("select"),
                  icon: const Icon(Icons.speed_rounded, size: 18),
                  label: Text(t.pages.proxies.testDelay),
                ),
              ),
            )
          : const SizedBox.shrink(),
    );

    final Widget listSliver = switch (proxies) {
      AsyncData(value: final group?) => SliverList.builder(
        itemCount: group.items.length,
        itemBuilder: (context, index) {
          final proxy = group.items[index];
          return ProxyTile(
            proxy,
            selected: group.selected == proxy.tag,
            onTap: () async {
              await ref.read(proxiesOverviewNotifierProvider.notifier).changeProxy(group.tag, proxy.tag);
            },
          );
        },
      ),
      AsyncError() => SliverToBoxAdapter(
        child: _Hint(text: t.pages.proxies.loadFailed, onTap: () => ref.invalidate(proxiesOverviewNotifierProvider)),
      ),
      AsyncLoading() when running => const SliverToBoxAdapter(
        child: Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
      ),
      _ => SliverToBoxAdapter(
        child: _Hint(text: running ? t.pages.proxies.empty : t.pages.proxies.connectToSeeProxies),
      ),
    };

    return Material(
      color: theme.colorScheme.surfaceContainerLow,
      clipBehavior: Clip.antiAlias,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: CustomScrollView(
        slivers: [
          profileSliver,
          testSliver,
          listSliver,
          // room for the quick settings tab that sits over the bottom edge
          const SliverToBoxAdapter(child: SizedBox(height: 48)),
        ],
      ),
    );
  }
}

class _Hint extends StatelessWidget {
  const _Hint({required this.text, this.onTap});

  final String text;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(text, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
      ),
    );
  }
}
